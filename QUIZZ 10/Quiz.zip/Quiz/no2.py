import  re
def check(email):
    if re.match('^[a-zA-Z]+@(?:[a-zA-Z]+\.)?ums\.ac\.id$', email):
        print("True")
    else:
        print("False")

if __name__ == "__main__":
    email = "yoga@ums.ac.id"
    check(email)

    email = "yoga@uns.ac.id"
    check(email)
    
    email = "yoga@student.ums.ac.id"
    check(email)

    email = "yoga@ums.com"
    check(email)


